@echo off

:startauth
set c="N"

echo.
echo ========== Authentication Scripts ==========
echo.
echo This Data collection is for Authentication Scenarios.
echo.
echo Once you have reproduced the issue, please run stopauth.bat to stop the tracing and collect the required data.
echo Data is collected in the c:\logs_%COMPUTERNAME% directory.
echo.
echo ============ IMPORTANT NOTICE ==============
echo.
echo The authentication script is designed to collect information that will help Microsoft Customer Support Services (CSS) troubleshoot an issue you may be experiencing with Windows.
echo The collected data may contain Personally Identifiable Information (PII) and/or sensitive data, such as (but not limited to) IP addresses; PC names; and user names.
echo.
echo Once the tracing and data collection has completed, the script will save the data in the "c:\logs_%COMPUTERNAME%" directory.
echo This folder is not automatically sent to Microsoft.
echo You can send this folder to Microsoft CSS using a secure file transfer tool - Please discuss this with your support professional and also any concerns you may have.
echo.
set /P c=Are you sure you want to continue[Y/N]?
if /I "%c%" EQU "Y" goto :start-script
if /I "%c%" EQU "N" goto :end-script
goto :startauth


:start-script
nltest /dbflag:0xFFFFFFFF
set NtlmDebugFlags=0x15003 
set NegoExtsDebugFlags=0xFFFF
set Pku2uDebugFlags=0xFFFF
set NtlmSharedDbFlags=0xffffffff
set KerbCommDbFlags=0xffffff
set KerbClientSharedDbFlags=0xffffffff

set LsatraceDbFlags=0xC03E8F
set LsaDStraceDbFlags=0x200
set LsaIsoDbFlags=0xffffffff
set VaultDbFlags=0xFFF
set SamSrvDbFlags=0xffffffffffffffff

REM **Create Folder**
cd c:/
mkdir .\logs_%COMPUTERNAME%\
del /f /q .\logs_%COMPUTERNAME%\*.*

REM **KERB Trace**
logman create trace "kerb" -ow -o .\logs_%COMPUTERNAME%\kerb.etl -p {BBA3ADD2-C229-4CDB-AE2B-57EB6966B0C4} 0xffffffffffffffff 0xff -nb 16 16 -bs 1024 -mode Circular -f bincirc -max 4096 -ets
logman update trace "kerb" -p {6B510852-3583-4E2D-AFFE-A67F9F223438} 0xffffffffffffffff 0xff -ets
logman update trace "kerb" -p "Microsoft-Windows-Security-Kerberos" 0xffffffffffffffff 0xff -ets

logman.exe start KerbComm -p {60A7AB7A-BC57-43E9-B78A-A1D516577AE3} %KerbCommDbFlags% -o .\logs_%COMPUTERNAME%\KerbComm.etl -ets
logman.exe start KerbClientShared -p {FACB33C4-4513-4C38-AD1E-57C1F6828FC0} %KerbClientSharedDbFlags% -o .\logs_%COMPUTERNAME%\KerbClientShared.etl -ets

REM **NTLM Trace**
logman create trace "ntlm" -ow -o .\logs_%COMPUTERNAME%\ntlm.etl -p "Microsoft-Windows-NTLM" 0xffffffffffffffff 0xff -nb 16 16 -bs 1024 -mode Circular -f bincirc -max 4096 -ets
logman update trace "ntlm" -p {5BBB6C18-AA45-49B1-A15F-085F7ED0AA90} %NtlmDbFlags% 0xff -ets
logman update trace "ntlm" -p "Microsoft-Windows-AuthenticationProvider" 0xffffffffffffffff 0xff -ets
logman update trace "ntlm" -p {C92CF544-91B3-4DC0-8E11-C580339A0BF8} 0xffffffffffffffff 0xff -ets

logman.exe start NtlmShared -p {AC69AE5B-5B21-405F-8266-4424944A43E9} %NtlmSharedDbFlags% -o .\logs_%COMPUTERNAME%\NtlmShared.etl -ets


REM **KDC Trace**
logman create trace KDC -ow -o .\logs_%COMPUTERNAME%\KDC.etl -p {1BBA8B19-7F31-43C0-9643-6E911F79A06B} 0xffffffffffffffff 0xff -nb 16 16 -bs 1024 -mode Circular -f bincirc -max 4096 -ets
logman update trace KDC -p {24DB8964-E6BC-11D1-916A-0000F8045B04} 0xffffffffffffffff 0xff -ets
logman update trace KDC -p "Microsoft-Windows-Kerberos-Key-Distribution-Center" 0xffffffffffffffff 0xff -ets

REM **Winlogon Trace**
logman create trace "profile" -ow -o .\logs_%COMPUTERNAME%\ms_winlogon.etl -p "Microsoft-Windows-Winlogon" 0xffffffffffffffff 0xff -nb 16 16 -bs 1024 -mode Circular -f bincirc -max 4096 -ets
logman update trace "profile" -p {D9391D66-EE23-4568-B3FE-876580B31530} 0xffffffffffffffff 0xff -ets
logman update trace "profile" -p {D451642C-63A6-11D7-9720-00B0D03E0347} 0xffffffffffffffff 0xff -ets
logman update trace "profile" -p {301779E2-227D-4FAF-AD44-664501302D03} 0xffffffffffffffff 0xff -ets
logman update trace "profile" -p {19D78D7D-476C-47B6-A484-285D1290A1F3} 0xffffffffffffffff 0xff -ets
logman update trace "profile" -p {C2BA06E2-F7CE-44AA-9E7E-62652CDEFE97} 0xffffffffffffffff 0xff -ets
logman update trace "profile" -p {eb7428f5-ab1f-4322-a4cc-1f1a9b2c5e98} 0xffffffffffffffff 0xff -ets

logman update trace "profile" -p {855ED56A-6120-4564-B083-34CB9D598A22} 0xffffffffffffffff 0xff -ets 
logman update trace "profile" -p {D138F9A7-0013-46A6-ADCC-A3CE6C46525F} 0xffffffffffffffff 0xff -ets 
logman update trace "profile" -p {63665931-A4EE-47B3-874D-5155A5CFB415} 0xffffffffffffffff 0xff -ets 
logman update trace "profile" -p {C127C1A8-6CEB-11DA-8BDE-F66BAD1E3F3A} 0xffffffffffffffff 0xff -ets 
logman update trace "profile" -p {BFA655DC-6C51-11DA-8BDE-F66BAD1E3F3A} 0xffffffffffffffff 0xff -ets 
logman update trace "profile" -p {A789EFEB-FC8A-4C55-8301-C2D443B933C0} 0xffffffffffffffff 0xff -ets 

REM **shell_FolderRedirection Traces**
logman create trace "shell_FolderRedirection" -ow -o .\logs_%COMPUTERNAME%\shell_FolderRedirection.etl -p "Microsoft-Windows-Folder Redirection" 0xffffffffffffffff 0xff -nb 16 16 -bs 1024 -mode Circular -f bincirc -max 4096 -ets
logman update trace "shell_FolderRedirection" -p {2955E23C-4E0B-45CA-A181-6EE442CA1FC0} 0xffffffffffffffff 0xff -ets


REM **EFS**
logman create trace "ds_EFS" -ow -o .\logs_%COMPUTERNAME%\ds_EFS.etl -p "Microsoft-Windows-EFS" 0xffffffffffffffff 0xff -nb 16 16 -bs 1024 -mode Circular -f bincirc -max 4096 -ets



REM **enable folder redirection Traces**
wevtutil.exe sl "Microsoft-Windows-Folder Redirection/Operational" /e:true
wevtutil.exe sl "Microsoft-Windows-Folder Redirection/Operational" /ms:10223616

REM **GPSVC Traces**
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Diagnostics" /v GPSvcDebugLevel /t REG_DWORD /d 0x00030002 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Diagnostics" /v FdeployDebugLevel /t REG_DWORD /d 0x0000000F /f
mkdir %WINDIR%\debug\usermode\ 



REM **GPO Traces**
logman.exe create trace "ds_grouppolicy" -ow -o .\logs_%COMPUTERNAME%\ds_grouppolicy.etl -p "Microsoft-Windows-GroupPolicy" 0xffffffffffffffff 0xff -nb 16 16 -bs 1024 -mode Circular -f bincirc -max 4096 -ets



REM **Profile Traces**

logman create trace "minio_profapi" -ow -o .\logs_%COMPUTERNAME%\minio_profapi.etl -p "Microsoft-Windows-User Profiles Service" 0xffffffffffffffff 0xff -nb 16 16 -bs 1024 -mode Circular -f bincirc -max 4096 -ets
logman update trace "minio_profapi" -p "Microsoft-Windows-User Profiles General" 0xffffffffffffffff 0xff -ets
logman update trace "minio_profapi" -p "Microsoft-Windows-Search-ProfileNotify" 0xffffffffffffffff 0xff -ets
logman update trace "minio_profapi" -p "Microsoft-Windows-System-Profile-HardwareId" 0xffffffffffffffff 0xff -ets
logman update trace "minio_profapi" -p {EB7428F5-AB1F-4322-A4CC-1F1A9B2C5E98} 0xffffffffffffffff 0xff -ets
logman update trace "minio_profapi" -p {63A3ADBE-9717-410D-A0F5-E07E68823B4D} 0xffffffffffffffff 0xff -ets

logman create trace "profsvc" -ow -o .\logs_%COMPUTERNAME%\profsvc.etl -nb 8 32 -bs 1024 -ets
logman update trace "profsvc" -p {9891e0a7-f966-547f-eb21-d98616bf72ee} 0xffffffffffffffff 0xff -ets
logman update trace "profsvc" -p {9959adbd-b5ac-5758-3ffa-ee0da5b8fe4b} 0xffffffffffffffff 0xff -ets
logman update trace "profsvc" -p {7f1bd045-965d-4f47-b3a7-acdbcfb11ca6} 0xffffffffffffffff 0xff -ets
logman update trace "profsvc" -p {40654520-7460-5c90-3c10-e8b6c8b430c1} 0xffffffffffffffff 0xff -ets
logman update trace "profsvc" -p {d5ee9312-a511-4c0e-8b35-b6d980f6ba25} 0xffffffffffffffff 0xff -ets
logman update trace "profsvc" -p {04a241e7-cea7-466d-95a1-87dcf755f1b0} 0xffffffffffffffff 0xff -ets
logman update trace "profsvc" -p {9aed307f-a41d-40e7-9539-b8d2742578f6} 0xffffffffffffffff 0xff -ets

REM **Ldap etl Traces**
logman create trace "ds_ds" -ow -o .\logs_%COMPUTERNAME%\ds_ldap.etl -p "Microsoft-Windows-LDAP-Client" 0x1a59afa3 0xff -nb 16 16 -bs 1024 -mode Circular -f bincirc -max 4096 -ets



REM **Network ETL Traces**
logman create trace "minio_netio" -ow -o .\logs_%COMPUTERNAME%\minio_netio.etl -p {EB004A05-9B1A-11D4-9123-0050047759BC} 0xffffffffffffffff 0xff -nb 16 16 -bs 1024 -mode Circular -f bincirc -max 2048 -ets 
logman update trace "minio_netio" -p "Microsoft-Windows-TCPIP" 0xffffffffffffffff 0xff -ets 
logman update trace "minio_netio" -p "Microsoft-Windows-Winsock-AFD" 0xffffffffffffffff 0xff -ets 
logman update trace "minio_netio" -p {B40AEF77-892A-46F9-9109-438E399BB894} 0xffffffffffffffff 0xff -ets 
logman update trace "minio_netio" -p {106b464a-8043-46b1-8cb8-e92a0cd7a560} 0xffffffffffffffff 0xff -ets  



REM **RPC Traces**
logman create trace "com_rpc" -ow -o .\logs_%COMPUTERNAME%\com_rpc.etl -p "Microsoft-Windows-RPC-Proxy-LBS" 0xffffffffffffffff 0xff -nb 16 16 -bs 1024 -mode Circular -f bincirc -max 4096 -ets
logman update trace "com_rpc" -p "Microsoft-Windows-RPC-Proxy" 0xffffffffffffffff 0xff -ets
logman update trace "com_rpc" -p "Microsoft-Windows-RPC-LBS" 0xffffffffffffffff 0xff -ets
logman update trace "com_rpc" -p "Microsoft-Windows-RPC" 0xffffffffffffffff 0xff -ets
logman update trace "com_rpc" -p "Microsoft-Windows-RPC-Events" 0xffffffffffffffff 0xff -ets
logman update trace "com_rpc" -p "Microsoft-Windows-RPCSS" 0xffffffffffffffff 0xff -ets
logman update trace "com_rpc" -p {9474A749-A98D-4F52-9F45-5B20247E4F01} 0xffffffffffffffff 0xff -ets
logman update trace "com_rpc" -p "Service Control Manager" 0xffffffffffffffff 0xff -ets
logman update trace "com_rpc" -p "Microsoft-Windows-Services" 0xffffffffffffffff 0xff -ets
logman update trace "com_rpc" -p {EBCCA1C2-AB46-4A1D-8C2A-906C2FF25F39} 0xffffffffffffffff 0xff -ets




REM **Other Traces**
logman.exe start negoexts -p {5AF52B0D-E633-4ead-828A-4B85B8DAAC2B} %NegoExtsDebugFlags% -o .\logs_%COMPUTERNAME%\negoexts.etl -ets
reg add HKLM\SYSTEM\CurrentControlSet\Control\Lsa\NegoExtender\Parameters /v InfoLevel /t REG_DWORD /d %NegoExtsDebugFlags% /f
logman.exe start pku2u -p {2A6FAF47-5449-4805-89A3-A504F3E221A6} %Pku2uDebugFlags% -o .\logs_%COMPUTERNAME%\pku2u.etl -ets
reg add HKLM\SYSTEM\CurrentControlSet\Control\Lsa\Pku2u\Parameters /v InfoLevel /t REG_DWORD /d %Pku2uDebugFlags% /f

REM **Schannel Trace**
logman.exe create trace "schannel" -ow -o .\logs_%COMPUTERNAME%\schannel.etl -p {37D2C3CD-C5D4-4587-8531-4696C44244C8} 0xffffffffffffffff 0xff -nb 16 16 -bs 1024 -mode Circular -f bincirc -max 4096 -ets
logman.exe update trace "schannel" -p {1F678132-5938-4686-9FDC-C8FF68F15C85} 0xffffffffffffffff 0xff -ets
logman.exe update trace "schannel" -p {44492B72-A8E2-4F20-B0AE-F1D437657C92} 0xffffffffffffffff 0xff -ets
logman.exe update trace "schannel" -p "Schannel" 0xffffffffffffffff 0xff -ets


REM **LSA Trace**
logman.exe start LsaTrace -p {D0B639E0-E650-4D1D-8F39-1580ADE72784} %LsatraceDbFlags% -o .\logs_%COMPUTERNAME%\LsaTrace.etl -ets
logman.exe start LsaDs -p {169EC169-5B77-4A3E-9DB6-441799D5CACB} %LsaDStraceDbFlags% -o .\logs_%COMPUTERNAME%\LsaDs.etl -ets
logman.exe start LsaIso -p {366B218A-A5AA-4096-8131-0BDAFCC90E93} %LsaIsoDbFlags% -o .\logs_%COMPUTERNAME%\LsaIso.etl -ets

REM **Vault**
logman.exe start vault -p {7FDD167C-79E5-4403-8C84-B7C0BB9923A1} %VaultDbFlags% -o .\logs_%COMPUTERNAME%\vault.etl -ets

REM **SamSrv
logman.exe start Samsrv -p {8E598056-8993-11D2-819E-0000F875A064} %SamSrvDbFlags% -o .\logs_%COMPUTERNAME%\samsrv.etl -ets

REM **PRE WIN 10 LSA LOGGING**
reg add HKLM\SYSTEM\CurrentControlSet\Control\LSA /v SPMInfoLevel /t REG_DWORD /d 0xC03E8F /f
reg add HKLM\SYSTEM\CurrentControlSet\Control\LSA /v LogToFile /t REG_DWORD /d 1 /f
reg add HKLM\SYSTEM\CurrentControlSet\Control\LSA /v NegEventMask /t REG_DWORD /d 0xF /f

REM **LSP Logging**
reg add HKLM\SYSTEM\CurrentControlSet\Control\LSA /v LspDbgInfoLevel /t REG_DWORD /d 0x41C20800 /f
reg add HKLM\SYSTEM\CurrentControlSet\Control\LSA /v LspDbgTraceOptions /t REG_DWORD /d 0x1 /f

REM **GMSA Logging**
logman create trace "ds_gmsa" -ow -o .\logs_%COMPUTERNAME%\ds_gmsa.etl -p {2D45EC97-EF01-4D4F-B9ED-EE3F4D3C11F3} 0xffffffffffffffff 0xff -nb 16 16 -bs 1024 -mode Circular -f bincirc -max 4096 -ets





REM **EVT LOGGING**
wevtutil.exe set-log Microsoft-Windows-CAPI2/Operational /enabled:true
wevtutil.exe clear-log Microsoft-Windows-CAPI2/Operational
wevtutil.exe sl Microsoft-Windows-CAPI2/Operational /ms:102400000

wevtutil.exe set-log Microsoft-Windows-Kerberos/Operational /enabled:true
wevtutil.exe clear-log Microsoft-Windows-Kerberos/Operational

REM netsh wfp capture start file=.\logs_%COMPUTERNAME%\wfpdiag.cab
net start > .\logs_%COMPUTERNAME%\services-started-at-log-start.txt


REM **EVT LOGGING**

wevtutil.exe set-log Microsoft-Windows-WebAuth/Operational /enabled:true
wevtutil.exe set-log Microsoft-Windows-Authentication/ProtectedUser-Client /enabled:true


reg add HKLM\SYSTEM\CurrentControlSet\Control\LSA /v SPMInfoLevel /t REG_DWORD /d 0x101F /f
reg add HKLM\SYSTEM\CurrentControlSet\Control\LSA /v LogToFile /t REG_DWORD /d 1 /f
reg add HKLM\SYSTEM\CurrentControlSet\Control\LSA /v NegEventMask /t REG_DWORD /d 0xF /f

REM **Network Trace**
Netsh trace start maxsize=2048 capture=yes traceFile=.\logs_%COMPUTERNAME%\netmon.cap overwrite=yes
echo Current time is %date%:%time% >.\logs_%COMPUTERNAME%\start_time.txt

REM **Get current Tickets**
klist > .\logs_%COMPUTERNAME%\tickets-start-before-flush.txt
klist -li 0x3e7 > .\logs_%COMPUTERNAME%\ticketscomputer-start-before-flush.txt

REM **Flush Tickets and DNS**
klist purge
klist -li 0x3e7 purge
ipconfig /flushdns


echo.
echo ====== Authentication scripts tracing started =======
echo.
echo The tracing has now started - once the issue is reproduced, please run stop-auth.bat to stop the tracing and to collect the data in the "logs" directory.
echo.
@echo on
pause
:end-script
