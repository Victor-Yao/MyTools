@echo off

:stopauth
set c="N"

echo.
echo ========== Authentication Scripts ==========
echo.
echo This Data collection is for Authentication Scenarios.
echo.
echo This scripts will stop the tracing that was previously activated with the start-auth.bat script.
echo Data is collected in the C:\logs_%COMPUTERNAME% directory.
echo.
echo ============ IMPORTANT NOTICE ==============
echo.
echo The authentication script is designed to collect information that will help Microsoft Customer Support Services (CSS) troubleshoot an issue you may be experiencing with Windows.
echo The collected data may contain Personally Identifiable Information (PII) and/or sensitive data, such as (but not limited to) IP addresses; PC names; and user names.
echo.
echo Once the tracing and data collection has completed, the script will save the data in the "C:\logs_%COMPUTERNAME%" directory.
echo This folder is not automatically sent to Microsoft.
echo You can send this folder to Microsoft CSS using a secure file transfer tool - Please discuss this with your support professional and also any concerns you may have.
echo.
set /P c=Are you sure you want to continue[Y/N]?
if /I "%c%" EQU "Y" goto :start-script
if /I "%c%" EQU "N" goto :end-script
goto :stopauth

:start-script
cd c:/
logman stop "kerb" -ets
logman stop "ds_EFS" -ets
logman.exe stop KerbComm -ets
logman.exe stop KerbClientShared -ets
logman stop "ntlm" -ets
logman.exe stop NtlmShared -ets
logman stop negoexts -ets
reg delete HKLM\SYSTEM\CurrentControlSet\Control\Lsa\NegoExtender\Parameters /v InfoLevel /f
logman.exe stop pku2u -ets
reg delete HKLM\SYSTEM\CurrentControlSet\Control\Lsa\Pku2u\Parameters /v InfoLevel /f
logman stop "schannel" -ets
reg delete HKLM\SYSTEM\CurrentControlSet\Control\LSA /v SPMInfoLevel /f
reg delete HKLM\SYSTEM\CurrentControlSet\Control\LSA /v LogToFile /f
reg delete HKLM\SYSTEM\CurrentControlSet\Control\LSA /v NegEventMask /f

logman.exe stop LsaTrace -ets
logman.exe stop LsaDs -ets
logman.exe stop LsaIso -ets
logman.exe stop vault -ets
logman.exe stop Samsrv -ets
logman.exe stop kdc -ets 

logman stop "minio_profapi" -ets
logman stop "profsvc" -ets
logman stop "profile" -ets
logman.exe stop "ds_grouppolicy" -ets
logman.exe stop "shell_FolderRedirection" -ets
logman stop "minio_netio" -ets
logman stop ds_ds -ets
logman stop "com_rpc" -ets
logman stop "ds_gmsa" -ets

copy /y %windir%\debug\usermode\gpsvc.log .\logs_%COMPUTERNAME%
copy /y %windir%\debug\usermode\fdeploy.log .\logs_%COMPUTERNAME% 
wevtutil.exe epl "Microsoft-Windows-Folder Redirection/Operational" .\logs_%COMPUTERNAME%\Folder-Redirection.evtx /q:"*[System[TimeCreated[timediff(@SystemTime) <= 86400000]]]"
wevtutil.exe sl "Microsoft-Windows-Folder Redirection/Operational" /e:false

wevtutil epl Security .\logs_%COMPUTERNAME%\security.evtx /q:"*[System[TimeCreated[timediff(@SystemTime) <= 86400000]]]"
wevtutil epl Microsoft-Windows-GroupPolicy/Operational .\logs_%COMPUTERNAME%\GroupPolicy-Operational.evtx /q:"*[System[TimeCreated[timediff(@SystemTime) <= 86400000]]]"

wevtutil epl "Microsoft-Windows-User Profile Service/Operational" .\logs_%COMPUTERNAME%\userprofile_operational.evtx /q:"*[System[TimeCreated[timediff(@SystemTime) <= 86400000]]]"
wevtutil epl "Microsoft-Windows-AAD/Operational" .\logs_%COMPUTERNAME%\AAD_Operational.evtx /q:"*[System[TimeCreated[timediff(@SystemTime) <= 864000000]]]"


echo Stopping NetTrace
netsh trace stop

REM netsh wfp capture stop

set > .\logs_%COMPUTERNAME%\env.txt

copy /y %windir%\debug\netlogon.log .\logs_%COMPUTERNAME%
copy /y %windir%\debug\netlogon.bak .\logs_%COMPUTERNAME%
copy /y %windir%\system32\lsass.log .\logs_%COMPUTERNAME%
copy /y %windir%\debug\netsetup.log .\logs_%COMPUTERNAME%
copy /y %windir%\debug\lsp.log .\logs_%COMPUTERNAME%
copy /y %windir%\debug\lsp.bak .\logs_%COMPUTERNAME%
copy /y %windir%\debug\adws.log .\logs_%COMPUTERNAME%


reg query "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion" /v BuildLabEx > .\logs_%COMPUTERNAME%\build.txt
reg query "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v CachedLogonsCount >.\logs_%COMPUTERNAME%\CachedLogonsCount.txt
reg query "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Lsa" /s > .\logs_%COMPUTERNAME%\lsa-key.txt
reg query "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies" /s > .\logs_%COMPUTERNAME%\Policies-key.txt
reg query "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\LanmanServer" /s > .\logs_%COMPUTERNAME%\lanmanserver-key.txt
reg query "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\LanmanWorkstation" /s > .\logs_%COMPUTERNAME%\lanmanworkstation-key.txt
reg query "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Netlogon" /s > .\logs_%COMPUTERNAME%\Netlogon-key.txt
reg query "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL" /s > .\logs_%COMPUTERNAME%\schannel-key.txt
reg query "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL" /s > .\logs_%COMPUTERNAME%\SSL_policy.txt 
reg query "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Cryptography" /s > .\logs_%COMPUTERNAME%\HKLMControl-Cryptography-key.txt
reg query "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Cryptography" /s > .\logs_%COMPUTERNAME%\HKLMSoftware-Cryptography-key.txt
reg query "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Cryptography" /s > .\logs_%COMPUTERNAME%\HKLMSoftware-policies-Cryptography-key.txt
reg query "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Authentication" /s > .\logs_%COMPUTERNAME%\Authentication-key.txt
reg query "HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Authentication" /s > .\logs_%COMPUTERNAME%\Authentication-key-wow64.txt
reg query "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Lsa" /s > .\logs_%COMPUTERNAME%\LSA_LmCompatibilityLevel.txt
reg query "HKEY_LOCAL_MACHINE\System\CurrentControlSet\Services\Netlogon\Parameters /s > .\logs_%COMPUTERNAME%\Parameters.txt

wmic datafile where "name='%SystemDrive%\\Windows\\System32\\kerberos.dll' or name='%SystemDrive%\\Windows\\System32\\lsasrv.dll' or name='%SystemDrive%\\Windows\\System32\\netlogon.dll' or name='%SystemDrive%\\Windows\\System32\\kdcsvc.dll' or name='%SystemDrive%\\Windows\\System32\\msv1_0.dll' or name='%SystemDrive%\\Windows\\System32\\schannel.dll' or name='%SystemDrive%\\Windows\\System32\\dpapisrv.dll' or name='%SystemDrive%\\Windows\\System32\\basecsp.dll' or name='%SystemDrive%\\Windows\\System32\\scksp.dll' or name='%SystemDrive%\\Windows\\System32\\bcrypt.dll' or name='%SystemDrive%\\Windows\\System32\\bcryptprimitives.dll' or name='%SystemDrive%\\Windows\\System32\\ncrypt.dll' or name='%SystemDrive%\\Windows\\System32\\ncryptprov.dll' or name='%SystemDrive%\\Windows\\System32\\cryptsp.dll' or name='%SystemDrive%\\Windows\\System32\\rsaenh.dll'  or name='%SystemDrive%\\Windows\\System32\\Cryptdll.dll'" get Filename, Version | more >> .\logs_%COMPUTERNAME%\build_dll.txt

nltest /dbflag:0x0
cmdkey.exe /list > .\logs_%COMPUTERNAME%\credman.txt
ipconfig /all > .\logs_%COMPUTERNAME%\ipconfig.txt
systeminfo > .\logs_%COMPUTERNAME%\systeminfo.txt
tasklist /svc >.\logs_%COMPUTERNAME%\tasklist_svc.txt
gpresult /h .\logs_%COMPUTERNAME%\gpresult.html
whoami /all>.\logs_%COMPUTERNAME%\whoami.txt
auditpol.exe /get /category:*>.\logs_%COMPUTERNAME%\auditpol.txt
dsregcmd /status > .\logs_%COMPUTERNAME%\dsregcmd.log 
netstat -anob > .\logs_%COMPUTERNAME%\netstat_anob.txt 
Netstat -anoq > .\logs_%COMPUTERNAME%\netstat_anoq.txt 
sc query > .\logs_%COMPUTERNAME%\services-config-at-log-finish.txt
net start > .\logs_%COMPUTERNAME%\services-started-at-log-finish.txt
klist > .\logs_%COMPUTERNAME%\tickets-stop.txt
klist -li 0x3e7 > .\logs_%COMPUTERNAME%\ticketscomputer-stop.txt
repadmin /showrepl /verbose /all>.\logs_%COMPUTERNAME%\showrepl.txt
repadmin /showrepl /repsto>.\logs_%COMPUTERNAME%\showreplrepsto.txt
Repadmin /replsummary>.\logs_%COMPUTERNAME%\repadmin_replsummary.txt
dcdiag /test:Replications /V /E /s:%COMPUTERNAME% /F:.\logs_%COMPUTERNAME%\dcdiag_replication.txt
dcdiag /test:FSMOCheck /V /E /s:%COMPUTERNAME% /F:.\logs_%COMPUTERNAME%\dcdiag_fsmo.txt
dcdiag /test:Advertising /V /E /s:%COMPUTERNAME% /F:.\logs_%COMPUTERNAME%\dcdiag_advertising.txt
dcdiag /test:services /V /E /s:%COMPUTERNAME% /F:.\logs_%COMPUTERNAME%\dcdiag_services.txt
dcdiag /test:netlogons /V /E /s:%COMPUTERNAME% /F:.\logs_%COMPUTERNAME%\dcdiag_netlogon.txt
dcdiag /s:%COMPUTERNAME% /q /f:.\logs_%COMPUTERNAME%\dcdiag_error.txt
Nltest /domain_trusts>.\logs_%COMPUTERNAME%\%computername%_trust.txt
wmic qfe list > .\logs_%COMPUTERNAME%\qfes_installed.txt
nltest /dclist:%USERDOMAIN%> .\logs_%COMPUTERNAME%\dclist.txt 
nltest /sc_verify:%USERDOMAIN%> .\logs_%COMPUTERNAME%\nltest_scverify.txt 

certutil.exe -v -silent -store my > .\logs_%COMPUTERNAME%\machine-store.txt
certutil.exe -v -silent -user -store my > .\logs_%COMPUTERNAME%\user-store.txt


wevtutil epl Security .\logs_%COMPUTERNAME%\security.evtx /q:"*[System[TimeCreated[timediff(@SystemTime) <= 86400000]]]"
wevtutil epl System .\logs_%COMPUTERNAME%\system.evtx /q:"*[System[TimeCreated[timediff(@SystemTime) <= 86400000]]]"
wevtutil epl Application .\logs_%COMPUTERNAME%\application.evtx /q:"*[System[TimeCreated[timediff(@SystemTime) <= 86400000]]]"


wevtutil.exe epl "Microsoft-Windows-Kerberos/Operational" .\logs_%COMPUTERNAME%\kerb_operational.evtx /q:"*[System[TimeCreated[timediff(@SystemTime) <= 86400000]]]"
wevtutil.exe sl "Microsoft-Windows-Kerberos/Operational" /e:false

wevtutil.exe epl "Microsoft-Windows-WebAuth/Operational" .\logs_%COMPUTERNAME%\webauth_operational.evtx /q:"*[System[TimeCreated[timediff(@SystemTime) <= 86400000]]]"
wevtutil.exe sl "Microsoft-Windows-WebAuth/Operational" /e:false

wevtutil.exe epl "Microsoft-Windows-Authentication/AuthenticationPolicyFailures-DomainController" .\logs_%COMPUTERNAME%\AuthenticationPolicyFailures-DomainController.evtx /q:"*[System[TimeCreated[timediff(@SystemTime) <= 86400000]]]"
wevtutil.exe sl "Microsoft-Windows-Authentication/AuthenticationPolicyFailures-DomainController" /e:false

wevtutil.exe epl "Microsoft-Windows-Authentication/ProtectedUser-Client" .\logs_%COMPUTERNAME%\authpolicy-ProtectedUser-Client.evtx /q:"*[System[TimeCreated[timediff(@SystemTime) <= 86400000]]]"
wevtutil.exe sl "Microsoft-Windows-Authentication/ProtectedUser-Client" /e:false

wevtutil epl "Microsoft-Windows-AAD/Operational" .\logs_%COMPUTERNAME%\AAD_Operational.evtx /q:"*[System[TimeCreated[timediff(@SystemTime) <= 864000000]]]"

wevtutil.exe epl Microsoft-Windows-CAPI2/Operational .\logs_%COMPUTERNAME%\capi2.evtx /q:"*[System[TimeCreated[timediff(@SystemTime) <= 8600000]]]"
wevtutil.exe sl Microsoft-Windows-CAPI2/Operational /e:false

wevtutil epl "DNS Server" .\logs_%COMPUTERNAME%\DNSServer.evtx /q:"*[System[TimeCreated[timediff(@SystemTime) <= 86400000]]]"
wevtutil epl "Directory Service" .\logs_%COMPUTERNAME%\DirectoryService.evtx /q:"*[System[TimeCreated[timediff(@SystemTime) <= 86400000]]]"

wevtutil epl "Active Directory Web Services" .\logs_%COMPUTERNAME%\ActiveDirectoryWebServices.evtx /q:"*[System[TimeCreated[timediff(@SystemTime) <= 86400000]]]"

echo Current time is %date%:%time% >.\logs_%COMPUTERNAME%\stop_time.txt

@echo off
@echo ===============
@echo ACTION REQUIRED
@echo ===============
@echo Tracing has been captured and saved successfully
@echo Please share c:\logs_%COMPUTERNAME%\* for analysis
@echo on
pause
:end-script