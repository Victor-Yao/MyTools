﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace CaculateServiceIIS
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "BasicArith" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select BasicArith.svc or BasicArith.svc.cs at the Solution Explorer and start debugging.
    public class BasicArith : IBasicArith
    {
        public int Sum(int num1, int num2)
        {
            return num1 +  num2;
        }

        public int Subtract(int num1, int num2)
        {
            return num1 - num2;
        }

        public int Multiply(int num1, int num2)
        {
            return num1 * num2;
        }

        public int Divide(int num1, int num2)
        {
            return num2 == 0 ? 1 : num1 / num2;
        }

        public string CheckIn()
        {
            return "Hey, there. I'm working";
        }
    }
}
