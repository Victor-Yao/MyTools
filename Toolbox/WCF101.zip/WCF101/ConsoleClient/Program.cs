﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using ConsoleClient.CaculateService;


namespace ConsoleClient
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var client1 = new BasicArithClient();
            var num1 = 1;
            var num2 = 2;
            Console.WriteLine(client1.CheckIn());
            Console.WriteLine($"{num1} + {num2}  = {client1.Sum(num1, num2)}");
            Console.WriteLine($"{num1} - {num2}  = {client1.Subtract(num1, num2)}");
            Console.WriteLine($"{num1} x {num2}  = {client1.Multiply(num1, num2)}");
            Console.WriteLine($"{num1} / {num2}  = {client1.Divide(num1, num2)}");
            Console.Read();

        }
    }
}
