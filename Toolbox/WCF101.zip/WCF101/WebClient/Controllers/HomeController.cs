﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebClient.CaculateService;

namespace WebClient.Controllers
{
    public class HomeController : Controller
    {
        BasicArithClient client = new BasicArithClient();

        [HttpPost]
        public ActionResult Sum(int num1, int num2)
        {
            ViewBag.Sum = client.Sum(num1, num2);
            return View("Index");
        }

        [HttpPost]
        public ActionResult Subtract(int num1, int num2)
        {
            ViewBag.Subtract = client.Subtract(num1, num2);
            return View("Index");
        }

        [HttpPost]
        public ActionResult Multiply(int num1, int num2)
        {
            ViewBag.Multiply = client.Multiply(num1, num2);
            return View("Index");
        }

        [HttpPost]
        public ActionResult Divide(int num1, int num2)
        {
            ViewBag.Divide = client.Divide(num1, num2);
            return View("Index");
        }

        [HttpPost]
        public ActionResult CheckIn()
        {
            ViewBag.Result = client.CheckIn();
            return View("Index");
        }

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}