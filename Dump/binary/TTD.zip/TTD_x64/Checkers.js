﻿// Copyright (C) Microsoft Corporation. All rights reserved.

"use strict"

var __currentUniqueIDForChecker = 0;
var __allowedCheckerTypes = ["Memory", "Security", "Other"];

// Higher priority should have a higher numerical value associated with it.
var __allowedCheckerPrioritiesDict = { "High": 1,  "Normal": 0, "Low": -1 };

const STATUS_COMPLETED = "Completed";
const STATUS_LOADED = "Loaded";
const STATUS_RUNNING = "Running";
const STATUS_QUEUED = "Queued";

const EVENT_RUN_CHECKER = "Checkers.RunChecker";
const EVENT_RUN_ALL_CHECKERS = "Checkers.RunAllCheckers";
const EVENT_RESTART_CHECKER = "Checkers.RestartChecker";
const EVENT_REPORT_CHECKER = "Checkers.ReportChecker";
const EVENT_REPORT_ALL_CHECKERS = "Checkers.ReportAllCheckers";
const EVENT_CHECKER_RESULTS = "Checkers.CheckerResults";
const EVENT_CHECKER_RUN_STARTED = "Checkers.CheckerRunStarted";
const EVENT_CHECKER_RUN_COMPLETED = "Checkers.CheckerRunCompleted";
const EVENT_CHECKER_RUN_FAILED = "Checkers.CheckerRunFailed";

// The class encapsulating implementation-defined checker function.
class Checker
{
    get [Symbol.metadataDescriptor]() 
    {
        return {
            Run: {
                PreferShow: true,
                Help: "Run(forceRun) - Runs the checker if the checker hasn't run to completion already." +
                " If `forceRun` is true, the checker logic is forced to run irrespective of previous runs." +
                " Default value of `forceRun` is false."
            },
            Report: {
                PreferShow: true,
                Help: "Report() - Prints the report of execution of checker on screen"
            },
            SaveReport: {
                PreferShow: true,
                Help: "SaveReport() - Saves the report of execution of checker to a file." + 
                " Displays the path to the saved file on screen."
            },
            Disable: {
                PreferShow: true,
                Help: "Disable() - Disables the checker"
            },
            Enable: {
                PreferShow: true,
                Help: "Enable() - Enables the checker"
            },
            ResultsToJson: {
                PreferShow: true,
                Help: "ResultsToJson(filePath) - Serializes the results into a JSON string and saves to specified file." +
                " Throws if filePath is null or undefined"
            },
            ResultsFromJson: {
                PreferShow: true,
                Help: "ResultsFromJson(filePath) - Reads a JSON string representation of results from the specified file," +
                " marking the Checker as 'Completed', and initializes the results collection."+
                " Throws if filePath is null, undefined or the content of the file can not be parse as Json."
            }
        };
    }

    constructor(name, type, metadata, checkerFunc, priority = "Normal")
    {
        if (name === undefined || isEmptyOrSpaces(name))
        {
            throw "Checker should contain valid Name"
        }
        this.__name = name;

        type = type.trim(); 
        if (!(__allowedCheckerTypes.includes(type)))
        {
            throw "Checker should have type among the allowed types: "+__allowedCheckerTypes.join(", ");
        }
        this.__type = type;

        priority = priority.trim();
        if (!(priority in __allowedCheckerPrioritiesDict))
        {
            throw "Checker should have a valid priority among allowed priorities: " + __allowedCheckerPrioritiesDict.keys().join(", ");
        }
        this.__priority = priority;
        this.__metadata = metadata;
        this.__checkerFunc = checkerFunc;
        this.__isEnabled = true;
        this.__status = STATUS_LOADED;
        this.__results = new ResultCollection();
        this.__reportGenerated = false;
        this.__runCompleted = false;
        this.__report = "";
        this.__uniqueID = __currentUniqueIDForChecker++;

        this.Run = function(forceRun = false) {
            return this.__runWorker(false, forceRun);
        }
    }

    get UniqueID()
    {
        return this.__uniqueID;
    }

    get Name()
    {
        return this.__name;
    }

    get Type()
    {
        return this.__type;
    }

    get Priority()
    {
        return this.__priority;
    }

    get Metadata()
    {
        return this.__metadata;
    }

    get IsEnabled()
    {
        return this.__isEnabled;
    }

    get Status()
    {
        return this.__status;
    }

    get Results()
    {
        sendEvent(EVENT_CHECKER_RESULTS);
        return this.__results;
    }

    __runWorker(isCalledByRunAll, forceRun) {
        if (!isCalledByRunAll)
        {
            if (forceRun)
            {
                sendEvent(EVENT_RESTART_CHECKER);
            }
            else
            {
                sendEvent(EVENT_RUN_CHECKER);
            }
        }

        if (this.__isEnabled)
        {
            if (forceRun === true || this.__runCompleted === false)
            {
                sendEvent(EVENT_CHECKER_RUN_STARTED, this.__uniqueID);
                if (forceRun === true)
                {
                    __logger.Log("Forcing run of checker: " + this.__name);
                }
                this.__status = STATUS_RUNNING;

                const t0 = Date.now();

                try
                {
                    this.__results = this.__checkerFunc();
                }
                catch(e)
                {
                    this.__status = STATUS_LOADED;
                    sendEvent(EVENT_CHECKER_RUN_FAILED);
                    __logger.Log("Run of checker failed due to error: " + e);
                    return [];
                }
                
                const t1 = Date.now();

                this.__status = STATUS_COMPLETED;
                this.__runCompleted = true;

                const executionTime = t1 - t0;
                this.__results.__ExecutionTime = executionTime;

                const lifetime = host.currentProcess.TTD.Lifetime;
                const numTTDPositions = lifetime.MaxPosition.Sequence - lifetime.MinPosition.Sequence;

                const traceFileName = __extractFileName(host.currentSession.Attributes.Target.Details.DumpFileName);
                const targetDetails = new TargetDetails(numTTDPositions, traceFileName);
                this.__results.__targetDetails = targetDetails;

                __logger.Log(`Execution time: ${executionTime} milliseconds`);
                __logger.Log(`TTD positions: ${numTTDPositions}`);

                try
                {
                    this.SaveReport();
                }
                catch(e)
                {
                    __logger.Log("Unable to save report after successful run of " + this.__name + " due to error: " + e);
                }

                sendEvent(EVENT_CHECKER_RUN_COMPLETED);
            }
            else if (this.__runCompleted === true)
            {
                __logger.Log(this.__name + " has already run. Returning cached results.");
            }
        }
        else
        {
            __logger.Log(this.__name + " is NOT enabled and therefore NOT run. Please use `Enable()` to enable the checker.");
            return [];
        }
        
        return this.__results;
    }

    __getFilePathToSaveReport()
    {
        var fileName = "Checkers" + "_" + this.__uniqueID.toString() + "_" +  this.__name + "_" + getMillisecondsSinceEpoch() + ".txt";
        var tempDirectoryPath = host.namespace.Debugger.Utility.FileSystem.TempDirectory + "\\";
        return tempDirectoryPath + fileName;
    }

    __reportInternal(printOnScreen = true)
    {
        if (this.__status === STATUS_COMPLETED)
        {
            if (this.__reportGenerated === false)
            {
                this.__report = __generateCheckerReport(this);
                this.__reportGenerated = true;
            }

            if (printOnScreen === true)
            {
                __printOnScreen(this.__report);
                return "";
            }
            else
            {
                return this.__report;
            }
        }
        else
        {
            __logger.Log(this.__name + " has NOT run to completion. Report is NOT available yet. Please use `Run()` to run the checker.");
            return "";
        }
    }

    Report()
    {
        sendEvent(EVENT_REPORT_CHECKER);
        return this.__reportInternal(true);
    }

    SaveReport()
    {
        if (this.__status === STATUS_COMPLETED)
        {
            var report = this.__reportInternal(false);
            var reportHeader = __generateReportHeader(this.__results.TargetDetails.TraceFileName);
            var reportWithHeader = reportHeader + report;
            var filePath = this.__getFilePathToSaveReport();
            SaveContentsToFile(reportWithHeader, filePath, "Report");
        }
        else
        {
            __logger.Log(this.__name + " has NOT run to completion. Report is NOT available yet." +
            " Report has NOT been saved. Please use `Run()` to run the checker.");
        }
    }

    Disable()
    {
        if (this.__isEnabled === false)
        {
            __logger.Log("[NO ACTION]. " + this.__name + " is already disabled.");
        }
        else
        {
            this.__isEnabled = false;
            __logger.Log(this.__name + " has been disabled.");
        }
    }

    Enable()
    {
        if (this.__isEnabled === true)
        {
            __logger.Log("[NO ACTION]. " + this.__name + " is already enabled.");
        }
        else
        {
            this.__isEnabled = true;
            __logger.Log(this.__name + " has been enabled.");
        }
    }
    
    // This methods exists just to add simetry to the API FromJson/ToJson
    ResultsToJson(filePath)
    {
        this.__results.__ToJson(filePath);
    }

    ResultsFromJson(filePath)
    {
        this.__results.__FromJson(filePath);
        this.__status = STATUS_COMPLETED;
        this.__reportGenerated = false;
        this.__runCompleted = true;
    }

    toString()
    {
        return "Checker: " + this.__name + ", Type: " + this.__type + ", Priority: " + this.__priority;
    }
}

// The class encapsulating the Checker Framework.
class CheckersAPI
{
    get [Symbol.metadataDescriptor]() 
    {
        return {
            Register: {
                PreferShow: false,
                Help: "Register(name, type, checkerMetadata, checkerFunc, priority) - Registers a TTD checker with given `checkerMetadata`. "
                + "`checkerFunc` is the checker logic that returns a `ResultCollection`. For creating metadata and result collections use " 
                + "utility methods under TTD.Checkers.Utility. `priority` is optional with default value of `Normal`. Allowed "
                + "values for `priority` are `High`, `Normal` and `Low`. "
                + "If a checker with the provided name already exists it gets replaced by the one registered by this function"
            },
            RunAll: {
                PreferShow: true,
                Help: "RunAll(forceRun) - Executes all registered checkers which are enabled and haven't completed yet. " +
                "The checkers are executed in the order of their priority, high priority first. If `forceRun` is true, all the " +
                " enabled checkers are executed irrespective of their prior executions. Default value of `forceRun` is false."
            },
            ReportAll: {
                PreferShow: true,
                Help: "ReportAll(saveToFile) - Shows reports of execution of all the completed checkers. " +
                    "If `saveToFile` is true, the report is saved to a file and the path to file is printed on screen. " +
                    "If `saveToFile` is false, the report is printed on screen. Default value of `saveToFile` is false."
            },
            Remove: {
                PreferShow: true,
                Help: "Remove(uniqueID) - Removes a checker whose unique ID is of the specified value"
            },
            RemoveByName: {
                PreferShow: true,
                Help: "RemoveByName(name) - Removes a checker whose name is of the specified value"
            },
            Get: {
                PreferShow: true,
                Help: "Get(uniqueID) - Returns a checker whose unique ID is of the specified value"
            },
            GetByName: {
                PreferShow: true,
                Help: "GetByName(name) - Returns a checker whose name is of the specified value"
            }
        };
    }

    constructor() 
    {
        // This array contains all the checkers that have been registered using Register() method.
        // The checkers are present in the order of their priorities. Higher priority checkers have lower indices.
        this.__registeredCheckers = [];

        this.__checkerUtilities = new CheckerUtilities();
    }

    *[Symbol.iterator]()
    {
        var idx = 0;
        for (var item of this.__registeredCheckers)
        {
            yield new host.indexedValue(item, [idx]);
            ++idx;
        }
    }

    getDimensionality()
    {
        return 1;
    }

    getValueAt(idx)
    {
        return this.__registeredCheckers[idx];
    }


    // A custom checker can be implemented using the facilities provided by the
    // Checker Framework. For writing custom checker scripts, the implementation should:
    //      1. Have a `checkerFunc()` that encapsulates the logic of the checker script.
    //          This logic is represented in the form of a function that returns a ResultCollection.
    //      2. Inside invokeScript(), call `cursession.TTD.Checkers.Register(name, type, checkerMetadata, checkerFunc, priority)` 
    //          method to register the checker with Checker Framework.
    //      3. Use `.scriptrun path/to/custom_checker.js` command to execute the script.
    Register(name, type, checkerMetadata, checkerFunc, priority = "Normal")
    {
        try
        {
            let checker = this.__initChecker(name, type, checkerMetadata, checkerFunc, priority);

            // TODO: Find a better way to fail an report the error to the user registering the checker
            if(!checker) {
                throw "Failed to initialize checker";
            }

            let oldCheckerIdx = this.__registeredCheckers.findIndex((checker) => checker.Name.trim() === name.trim());

            if(oldCheckerIdx === -1) 
            {
                this.__registeredCheckers.push(checker);
            }
            else
            {
                this.__registeredCheckers[oldCheckerIdx] = checker;
            }

            // Sort the checkers w.r.t their priorities.
            this.__registeredCheckers.sort(
                (a,b) => __allowedCheckerPrioritiesDict[b.Priority] - __allowedCheckerPrioritiesDict[a.Priority]
            )
            return checker;
        }
        catch(e)
        {
            __logger.Log("Registration of checker " +
            ( name === undefined ? "with unknown name" : name ) + " failed with error " + e);
            // TODO: Find a better way to fail
            // If we re-throw the error, when calling from the Debugger model it will convert the
            // error to an object that will be registered as a namedModelParent.

        }
    }

    // This method creates a checker object with the given Metadata (As it will appear in the model) 
    // and a Run function that will eventually call the user provided checkerFunc.
    // `checkerFunc` is a function that returns a collection of results i.e. ResultCollection.
    __initChecker(name, type, checkerMetadata, checkerFunc, priority)
    { 
        //Instantiate a Checker object.
        try
        {
            let checkerObj = new Checker(name, type, checkerMetadata, checkerFunc, priority);
            return checkerObj;
        }
        catch(e)
        {
            __logger.Log("Failed to initialize checker " +
            ( name === undefined ? "with unknown name" : name ) + " due to error: " + e);
        }
    }

    RunAll(forceRun = false)
    {
        sendEvent(EVENT_RUN_ALL_CHECKERS);
        
        // The checkers are present in the array in the order of their priorities.
        // Higher priority checkers will have lower indices and will run first.
        for (var checker of this.__registeredCheckers)
        {
            // Queue all the checkers that are enabled and have not completed yet.
            if (checker.__isEnabled && (forceRun === true || checker.__status !== STATUS_COMPLETED))
            {
                checker.__status = STATUS_QUEUED;
            }
        }

        for (var checker of this.__registeredCheckers)
        {
            if (checker.__status === STATUS_QUEUED)
            {
                __logger.Log("Executing: " + checker.Name + ", Priority: " + checker.Priority);

                try
                {
                    checker.__runWorker(true, forceRun);
                }
                catch(e)
                {
                    __logger.Log("Execution of checker " + checker.Name + " failed with error " + e);
                }
            }
            else
            {
                __logger.Log("Skipping execution of " + checker.Name + ", IsEnabled: " + checker.IsEnabled + 
                ", Status: " + checker.Status);
            }
        }
    }

    ReportAll(saveToFile = false)
    {
        sendEvent(EVENT_REPORT_ALL_CHECKERS);
        var cummulativeReport = "";
        for (var checker of this.__registeredCheckers)
        {
            if (checker.__status === STATUS_COMPLETED)
            {
                var displayMessage = "Reporting results of " + checker.Name;
                __logger.Log(displayMessage); 
                cummulativeReport += checker.__reportInternal(false);
            }
            else
            {
                var displayMessage = "Skipping results of " + checker.Name;
                __logger.Log(displayMessage); 
            }
        }

        if (isEmptyOrSpaces(cummulativeReport))
        {
            cummulativeReport = "Report is empty because no checker has completed execution.";
        }

        cummulativeReport = __generateReportHeader() + cummulativeReport;

        if (saveToFile === true)
        {
            var fileSystem = host.namespace.Debugger.Utility.FileSystem;
            var filePath = fileSystem.TempDirectory + "\\" + "CheckersExecutionReport" + "_" + getMillisecondsSinceEpoch() + ".txt";
            SaveContentsToFile(cummulativeReport, filePath, "Cummulative Report");
        }
        else
        {
            __printOnScreen(cummulativeReport);
        }
    }

    Remove(uniqueID)
    {
        this.__registeredCheckers = this.__registeredCheckers.filter(c => c.UniqueID != uniqueID);
    }

    RemoveByName(name)
    {
        this.__registeredCheckers = this.__registeredCheckers.filter(c => c.Name != name);
    }

    Get(uniqueID)
    {
        let checker = this.__registeredCheckers.find(c => c.UniqueID == uniqueID);
        if (!checker)
        {
            __logger.Log("Checker with the specified unique ID not found.");
        }
        return checker;
    }

    GetByName(name)
    {
        let checker = this.__registeredCheckers.find(c => c.Name == name);
        if (!checker)
        {
            __logger.Log("Checker with the specified name not found.");
        }
        return checker;
    }

    RemoveAll()
    {
        this.__registeredCheckers = [];
    }

    get Utility()
    {
        return this.__checkerUtilities;
    }

    toString()
    {
        return "Checkers (scripts for detection of common issues recorded in a time travel trace)"
    }
}

class Metadata
{
    constructor(owner, description)
    {
        // TODO: Strict email verfication can be done through regex.
        if (owner === undefined || isEmptyOrSpaces(owner) || !(owner.includes("@")))
        {
            throw "Each checker should have a valid owner email"
        }
        this.__owner = owner;

        if (description === undefined)
        {
            description = "Checker: " + name + " of type " + type + " by " + owner;
        }
        this.__description = description;
    }

    get Owner()
    {
        return this.__owner;
    }

    get Description()
    {
        return this.__description;
    }

    toString()
    {
        return "Checker" + " by " + this.__owner;
    }
}

class Location
{
    constructor(position, description, properties = null)
    {
        if (position.Sequence === undefined || position.Steps === undefined)
        {
            throw "Location must be initialized at a valid position";
        }
        this.__position = position;

        if (description === undefined || isEmptyOrSpaces(description))
        {
            description = "Location: " + position.toString();
        }
        this.__description = description;

        this.__properties = properties;
    }

    get Position()
    {
        return this.__position;
    }

    get Description()
    {
        return this.__description;
    }

    get Properties()
    {
        return this.__properties;
    }

    toString()
    {
        return "Location object at: " + this.__position.ToString();
    }
}

class LocationCollection
{
    get [Symbol.metadataDescriptor]() 
    {
        return {
            AddLocation: {
                PreferShow: false,
                Help: "AddLocation(position, description, properties) - Creates an evidence location. `description` is optional. " + 
                "`properties` (optional) is any location specific information."
            },
            RemoveLocation: {
                PreferShow: false,
                Help: "RemoveLocation(location) - Given a `location` object, removes it from the collection."
            }
        };
    }

    constructor()
    {
        this.__locations = [];
    }

    AddLocation(position, description, properties = null)
    {
        try
        {
            var location = new Location(position, description, properties);
            this.__locations.push(location);
        }
        catch(e)
        {
            __logger.Log("Failed to add location due to error: " + e);
        }  
    }

    RemoveLocation(location)
    {
        for (var i = 0; i < this.__locations.length; i++)
        {
            if (this.__locations[i] === location)
            {
                this.__locations.splice(i,1);
                return;
            }
        }
    }

    *[Symbol.iterator]()
    {
        yield* this.__locations;
    }

    __serialize()
    {
        var serialLocations = this.__locations.map(
            x =>
            {
                return {
                    Sequence: x.Position.Sequence.asNumber(),
                    Steps: x.Position.Steps.asNumber(),
                    Description: x.Description
                }
            }
        );
        return serialLocations;
    }

    __deserialize(serialLocations)
    {
        this.__locations = serialLocations.map(
            x =>
            {
                var position = host.namespace.Debugger.Utility.Objects.CreateInstance(
                    "Debugger.Models.TTD.Position",
                    x.Sequence,
                    x.Steps
                )
                return new Location(position, x.Description);
            }
        )
    }

    toString()
    {
        return "Location collection";
    }
}

var __allowedCheckerResultSeverityLevels = ["Error", "Warning", "Message"];

class Result
{
    constructor(severity, title, description, locationCollection)
    {
        if (isEmptyOrSpaces(severity) || !(__allowedCheckerResultSeverityLevels.includes(severity)))
        {
            throw "Result should have severity among allowed severity levels: "+__allowedCheckerResultSeverityLevels.join(", ");
        }
        this.__severity = severity;

        if (title === undefined || isEmptyOrSpaces(title))
        {
            throw "Result should have a valid title";
        }
        this.__title = title;

        if (description === undefined || isEmptyOrSpaces(description))
        {
            description = "Result: " + title + ". Severity: " + severity;
        }
        this.__description = description;

        if(locationCollection === undefined)
        {
            locationCollection = new LocationCollection();
        }
        this.__locationCollection = locationCollection;
    }

    get Severity()
    {
        return this.__severity;
    }

    get Title()
    {
        return this.__title;
    }

    get Description()
    {
        return this.__description;
    }

    get Locations()
    {
        return this.__locationCollection;
    }

    toString()
    {
        return "Result object: " + this.__title;
    }
}

class ResultCollection
{
    get [Symbol.metadataDescriptor]() 
    {
        return {
            AddResult: {
                PreferShow: false,
                Help: "AddResult(severity, title, description, locations) - Adds a new Result to the collection. `description` is optional. " +
                    "`locations` is of type `LocationCollection`. If `locations` object isn't specified then the Result is initialized with an " +
                    " empty LocationCollection."
            },
            RemoveResult: {
                PreferShow: false,
                Help: "RemoveResult(result) - Given a `result` object, removes it from the collection."
            },
        };
    }

    constructor()
    {
        this.__results = [];
        this.__executionTime = "Execute the checker or load results from a json file to get its execution time";
    }

    get Count()
    {
        return this.__results.length;
    }

    get ExecutionTime()
    {
        return this.__executionTime;
    }

    set __ExecutionTime(value)
    {
        this.__executionTime = value;
    }

    get TargetDetails()
    {
        return this.__targetDetails;
    }
    
    AddResult(severity, title, description, locations)
    {
        try
        {
            var result = new Result(severity, title, description, locations);
            this.__results.push(result);
        }
        catch(e)
        {
            __logger.Log("Failed to add result with title: " + title + " due to error: " + e);
        }
    }

    RemoveResult(result)
    {
        for (var i = 0; i < this.__results.length; i++)
        {
            if (this.__results[i] === result)
            {
                this.__results.splice(i,1);
                return;
            }
        }
    }

    *[Symbol.iterator]()
    {
        yield* this.__results;
    }

    __serialize()
    {
        var serialResults = this.__results.map(
            x =>
            {
                return {
                    Severity: x.Severity.toString(),
                    Title: x.Title.toString(),
                    Description: x.Description.toString(),
                    Locations: x.Locations.__serialize()
                }
            }
        );
        
        return {
            ExecutionTime: this.ExecutionTime,
            TargetDetails: this.TargetDetails.__serialize(),
            Results: serialResults
        }
    }

    __deserialize(serialResults)
    {
        this.__executionTime = serialResults.ExecutionTime;
        this.__targetDetails = TargetDetails.__deserialize(serialResults.TargetDetails);
        this.__results = serialResults.Results.map(
            x =>
            {
                var locationCollection = new LocationCollection();
                locationCollection.__deserialize(x.Locations);

                return new Result(x.Severity, x.Title, x.Description, locationCollection);
            }
        );
    }

    __ToJson(filePath)
    {
        if (filePath === undefined || filePath === null)
        {
            throw "A valid filePath should be provided"
        }
        var serialResults = this.__serialize();
        var serialResultsJson = JSON.stringify(serialResults, null, 2);
        SaveContentsToFile(serialResultsJson, filePath, "Results");
    }

    __FromJson(filePath)
    {
        if (filePath === undefined || filePath === null)
        {
            throw "A valid filePath should be provided"
        }
        var serialResultsJson = LoadContentsFromFile(filePath, "Results");
        var serialResults = JSON.parse(serialResultsJson);
        this.__deserialize(serialResults);
    }

    toString()
    {
        return "Result collection";
    }
}

class TargetDetails
{
    constructor(numTTDPositions, traceFileName)
    {
        if (!Number.isFinite(numTTDPositions))
        {
            throw "numTTDPositions must be a number";
        }
        if (!traceFileName)
        {
            throw "A valid trace file name should be provided";
        }
        this.__numTTDPositions = numTTDPositions;
        this.__traceFileName = traceFileName;
    }

    get NumTTDPositions()
    {
        return this.__numTTDPositions;
    }

    get TraceFileName()
    {
        return this.__traceFileName;
    }

    __serialize()
    {
        return {
            NumTTDPositions: this.NumTTDPositions,
            TraceFileName: this.TraceFileName,
        }
    }

    static __deserialize(serialDetails)
    {
        return new TargetDetails(serialDetails.NumTTDPositions, serialDetails.TraceFileName);
    }

    toString()
    {
        return "Target details";
    }
}

class CheckerUtilities
{
    get [Symbol.metadataDescriptor]() 
    {
        return {
            CreateMetadata: {
                PreferShow: false,
                Help: "CreateMetadata(owner, description) - Creates a checker Metadata object with given string parameters"
            },
            CreateLocationsCollection: {
                PreferShow: false,
                Help: "CreateLocationsCollection() - Creates a Locations collection that stores evidence locations of a discovered issue"
            },
            CreateResultsCollection: {
                PreferShow: false,
                Help: "CreateResultsCollection() - Creates a Results collection to store issues discovered by a checker"
            }
        };
    }

    CreateMetadata(owner, description)
    {
        return new Metadata(owner, description)
    }
    
    CreateLocationsCollection()
    {
        return new LocationCollection();
    }

    CreateResultsCollection()
    {
        return new ResultCollection();
    }

    toString()
    {
        return "Utilities used by a checker implementation to create Checker Framework specific objects in a script"
    }
}


class Logger
{
    Log(message)
    {
        host.diagnostics.debugLog(message + "\n");
    }

    Report(message)
    {
        // TODO: Implement report functionality to log messages to a file.
    }
}

var __logger = new Logger();

function __countArrayElements(array, predicate = null)
{
    if (array === undefined || array === null || array.length === 0)
    {
        return 0;
    }

    if (predicate === null)
    {
        return array.length;
    }

    var count = array.reduce(function(n, val) {
        return n + (predicate(val) === true ? 1 : 0);
    }, 0);

    return count;
}

function __printOnScreen(inputString)
{
    if(inputString == undefined || inputString == null)
    {
        return;
    }

    var lines = inputString.split('\n');
    for(var line of lines)
    {
        __logger.Log(line.trimRight());
    }
}

function __generateReportHeader(traceFileName = null, startIndent = "")
{
    if (!traceFileName)
    {
        traceFileName = host.currentSession.Attributes.Target.Details.DumpFileName;
    }
    traceFileName = __extractFileName(traceFileName);
    
    var currentDateTime = new Date();
    var reportHeader =
`${startIndent}Copyright (C) Microsoft Corporation. All rights reserved.
${startIndent}======================================================================================================================================
${startIndent}Report Generated at: ${currentDateTime.toUTCString()}
${startIndent}Target Trace File: ${traceFileName}
${startIndent}======================================================================================================================================
`;

    return reportHeader;
}

function __generateCheckerReport(checker, startIndent = "", indent = "  ")
{
    var report = 
`
${startIndent}======================================================================================================================================
${startIndent}Report for Checker: ${checker.Name}
${startIndent}======================================================================================================================================
${startIndent}${indent}Checker Details:
${startIndent}${indent}${indent}Checker Type: ${checker.Type}
${startIndent}${indent}${indent}Checker Description: ${checker.Metadata.Description}
${startIndent}${indent}${indent}Checker Owner: ${checker.Metadata.Owner} (Please contact the owner to report false positives for this checker.)
${startIndent}${indent}======================================================================================================================================
${startIndent}${indent}Results of checker execution:
${startIndent}${indent}${indent}Execution Time:  ${checker.__results.ExecutionTime} milliseconds
${startIndent}${indent}${indent}Number of TTD Positions:  ${checker.__results.TargetDetails.NumTTDPositions}
${startIndent}${indent}${indent}Total Issues found:  ${__countArrayElements(checker.__results.__results)}
${startIndent}${indent}${indent}${indent}Errors:     ${__countArrayElements(checker.__results.__results, (x) => { return x.Severity === "Error"})} 
${startIndent}${indent}${indent}${indent}Warnings:   ${__countArrayElements(checker.__results.__results, (x) => { return x.Severity === "Warning"})}
${startIndent}${indent}${indent}${indent}Messages:   ${__countArrayElements(checker.__results.__results, (x) => { return x.Severity === "Message"})}
${startIndent}${indent}======================================================================================================================================
`;

    if (checker.__results.__results.length > 0)
    {
        report +=
`${startIndent}${indent}Detailed Report:
`;

        var resultInd = 1;
        for (var result of checker.__results.__results)
        {
            report +=
`${startIndent}${indent}${indent}--------------------------------------------------------------------------------------------------------------------------------------
${startIndent}${indent}${indent}--------------------------------------------------------------------------------------------------------------------------------------
${startIndent}${indent}${indent}Issue ${resultInd}, ${result.Severity}: ${result.Title}
${startIndent}${indent}${indent}${indent}Description: ${result.Description}
${startIndent}${indent}${indent}${indent}Number of Locations for evidence: ${__countArrayElements(result.Locations.__locations)}
${startIndent}${indent}${indent}${indent}Locations:
`;

            var locInd = 1;
            for (var location of result.Locations.__locations)
            {
                report +=
`${startIndent}${indent}${indent}${indent}${indent}Location ${locInd}, [${location.Position.toString()}]
${startIndent}${indent}${indent}${indent}${indent}${indent}Description: ${location.Description}
`     
                if (location.Properties !== null)
                {
                    var jsonFormattedProperites = JSON.stringify(location.Properties, null, indent);
                    var jsonFormattedProperitesWithStartIndent = jsonFormattedProperites.replace(
                        /\n/g, 
                        `\n${startIndent}${indent}${indent}${indent}${indent}${indent}`
                    );
                    report +=
`${startIndent}${indent}${indent}${indent}${indent}${indent}Additional Properties: 
${startIndent}${indent}${indent}${indent}${indent}${indent}${jsonFormattedProperitesWithStartIndent}
`;
                }
                locInd++;          
            }

            report += "\n";
            resultInd++;
        }
    }

    report +=
`${startIndent}======================================================================================================================================
${startIndent}End of Report for Checker: ${checker.Name}
${startIndent}======================================================================================================================================
`;
    return report;
}

function getMillisecondsSinceEpoch()
{
    var currentDate = new Date();
    var milliSecondsSinceEpoch = currentDate.getTime();
    return milliSecondsSinceEpoch.toString();
}

// Utility function to check if a string is null or whitespace
function isEmptyOrSpaces(str){
    return str === null || str.match(/^ *$/) !== null;
}

function __extractFileName(filePath, separator='\\')
{
    return filePath ? filePath.split(separator).pop() : "";
}

function sanitizeFilePath(filePath)
{
    // Adding /g replaces all occurences of a pattern.
    // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/replace
    var filePathWithSpacesFixed = filePath.replace(/\s/g, '_');
    var filePathWithPathSeparatorFixed = filePathWithSpacesFixed.replace(/\\/g, '\\\\');

    return filePathWithPathSeparatorFixed;
}

function SaveContentsToFile(contents, filePath, contentType)
{
    filePath = sanitizeFilePath(filePath);
    var fileSystem = host.namespace.Debugger.Utility.FileSystem;

    try
    {
        var fileHandle = fileSystem.CreateFile(filePath);
        var writer = fileSystem.CreateTextWriter(fileHandle, 'Utf8');
        writer.WriteLine(contents);
        __logger.Log(contentType.toString() +" saved to file: " + filePath);
    }
    catch(e)
    {
        return __logger.Log("Unable to save " + contentType.toString() + " to file: " 
        + filePath + " due to error: " + e.toString());
    }
    finally
    {
        if (fileHandle !== undefined && fileHandle !== null)
        {
            fileHandle.Close();
        }
    }
}

function LoadContentsFromFile(filePath, contentType)
{
    filePath = sanitizeFilePath(filePath);
    var fileSystem = host.namespace.Debugger.Utility.FileSystem;

    try
    {
        var fileHandle = fileSystem.OpenFile(filePath);
        var reader = fileSystem.CreateTextReader(fileHandle, 'Utf8');

        let lines = reader.ReadLineContents();
        let content = "";
        for (let line of lines) {
            content += line
        }
        __logger.Log(contentType.toString() + " loaded from file: " + filePath);
        return content;
    }
    catch(e)
    {
        __logger.Log("Unable to load " + contentType.toString() + " from file: " 
            + filePath + " due to error: " + e.toString());
    }
    finally
    {
        if (fileHandle !== undefined && fileHandle !== null)
        {
            fileHandle.Close();
        }
    }
}

// A dictionary to store an instance of CheckersAPI for each new target dump file
var __sessionCheckersDict = {};

var ttdCheckers =
{ 
    get Checkers()
    {
        // Instantiate new CheckersAPI for each new target dump file.
        // For a given dump file, cache the already instantiated CheckersAPI
        var file = this.Attributes.Target.Details.DumpFileName;
        if (!(file in __sessionCheckersDict))
        {
            __sessionCheckersDict[file] = new CheckersAPI();
        }
        
        return __sessionCheckersDict[file];
    }
};

// Send a checkers command event via the XML notification stream for telemetry purposes.
// EVENT_CHECKER_RUN_STARTED is sent with checker's unique ID as args.
function sendEvent(event, args = null)
{
    host.namespace.Debugger.Utility.Events.SendEvent(event, args);
}

function initializeScript()
{
    return  [ 
        new host.apiVersionSupport(1, 3),
        new host.namedModelParent(ttdCheckers, "TTDAnalyze"),
        new host.namedModelRegistration(CheckersAPI, "TTDAnalyze.Checkers")
    ];
}
