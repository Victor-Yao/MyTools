﻿//begin_both
//-------------------------------------------------------------------------------------------------------------
//
// TtdAnalyzer.js - "Base class" for TTDAnalyze extensions to the debugger data model.
//
// Copyright (C) Microsoft Corporation. All rights reserved.
//end_both
//begin_internal
// This is the foundation for higher level data model query and analysis of TTD traces. It
// establishes a namespace that looks like this:
// 
// Debugger.Models.Session  - root namespace
//    |
//    +--   .TTDAnalyze         - Functionality supplied by ttdanalyze.dll (e.g. .Calls()); appears as .TTD, not .TTDAnalyze, in the debugger.
//      |                         [See SessionTtdModel's constructor in ModelProvider.cpp and CheckerAnalysis::InitializeModels()
//      |                          in CheckerAnalysis.cpp for more details on how the native code is integrated into the data model.]
//      +--     .Data           - Normalized data sources that queries can build upon (e.g. .Heap() for heap APIs)
//      |
//      +--     .Utility        - Useful methods for analyzing traces (e.g. .GetHeapAddress() which searches
//      |                         .Data.Heap(address) for operations that impact address.)
//      +--     .Analyzers      - Methods that perform analysis on the trace (e.g. a method to diagnose heap exceptions)
//        |
//        +--       .Analyze()  - Method that calls all "registered" methods under .Analyze. Today "registration" means
//                                placing the method in the .Analyzers namespace and prefixing the function with
//                                "Analyzer_<ScriptName>_". (e.g. HeapAnalysis.js defines a Analyze_HeapAnalysis_HeapException
//                                method which gets called when .Analyze() is called.)
//
// In the debugger the data model appears as @$cursession.TTD[.Data/.Utility/.Analyzers].
//
// SampleAnalyzer.js demonstrates how to extend each of these namespaces. HeapAnalysis.js can be used as a 'real' example.
//
// Note that there is a shortcut for executing @$cursession.TTD.Analyzers.Analyze(): !ttdanalyze. This command will
// execute all native analyzers + script analyzers and assign the result to @$ttdAnalyze (which can be used for further
// display/querying/analysis.)
//end_internal
//begin_both
//-------------------------------------------------------------------------------------------------------------

"use strict";

class ttdData
{
    constructor(session)
    {
        // Hold on to the session that the object is created with and use that in subsequent queries
        this.__session = session;
    }

    // Make the captured session object available to extensions
    capturedSession()
    {
        return this.__session;
    }

    toString()
    {
        return "Normalized data sources based on the contents of the time travel trace";
    }
}

class ttdUtility
{
    constructor(session)
    {
        // Hold on to the session that the object is created with and use that in subsequent queries
        this.__session = session;
    }

    // Make the captured session object available to extensions
    capturedSession()
    {
        return this.__session;
    }

    // Comparison function for time positions
    // usage:
    //   Debugger:      dx -g @$calls.OrderBy(x => x.TimeStart, @$cursession.TTD.Utility.compareTime)
    //   JavaScript:    var calls = host.currentSession.TTD.Calls("ucrtbase!initterm").OrderBy(
    //                                function (c) { return c.TimeStart; },
    //                                host.currentSession.TTD.Utility.compareTime
    //                                );
    compareTime(t1, t2)
    {
        return t1.compareTo(t2);
    }

    toString()
    {
        return "Methods that can be useful when analyzing time travel traces";
    }
}

//end_both
//begin_internal    
class ttdAnalyzers
{
    constructor(session)
    {
        // Hold on to the session that the object is created with and use that in subsequent queries
        this.__session = session;
    }

    get [Symbol.metadataDescriptor]()
    {
        return {
            capturedSession : { PreferShow : false },
            Analyze : { PreferShow : true, Help : "Runs all registered checkers against the time travel trace" }
        }
    }

    // Make the captured session object available to extensions
    capturedSession()
    {
        return this.__session;
    }

    Analyze()
    {
        host.diagnostics.debugLog("Running all registered analyzers...\n");

        // Walk up the chain of prototypes and call any function that start with Analyze_
        var results = [];
        var current = this;
        while (current)
        {
            var keys = Object.getOwnPropertyNames(current);
            for (var key of keys)
            {
                if (key.startsWith("Analyze_"))
                {
                    var result = current[key].apply(this);
                    if (result !== undefined)
                    {
                        results = results.concat(result);
                    }
                }
            }
            current = Object.getPrototypeOf(current);
        }

        return results;
    }

    toString()
    {
        return "Methods that perform code analysis on the time travel trace";
    }
}
//end_internal
//begin_both

var ttdExtension =
{
    get Data()      { return new ttdData     (this); },
    get Utility()   { return new ttdUtility  (this); },
//end_both
//begin_internal    
    get Analyzers() { return new ttdAnalyzers(this); }
//end_internal
//begin_both
}

function initializeScript()
{
    return [
        new host.apiVersionSupport(1, 2),
        new host.namedModelParent      (ttdExtension,   "TTDAnalyze"),
        new host.namedModelRegistration(ttdData,        "TTDAnalyze.Data"),
        new host.namedModelRegistration(ttdUtility,     "TTDAnalyze.Utility"),
//end_both
//begin_internal    
        new host.namedModelRegistration(ttdAnalyzers,   "TTDAnalyze.Analyzers")
//end_internal
//begin_both
    ];
}
//end_both
